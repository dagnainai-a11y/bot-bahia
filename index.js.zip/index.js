const { Client, GatewayIntentBits, EmbedBuilder } = require('discord.js');

// Cria o cliente do bot com as permissões necessárias
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

// Substitua pelo token que você copiou no Passo 1
const TOKEN = 'MTU3MjAxMzAwNjU5Njk5NzE4Mg.G5VTXF.rl4H7uR0FUWqGqZ3QobBaLnrPpxlrBX8ZM4eLk';

client.once('ready', () => {
  console.log(`🔥 ${client.user.tag} está online! Bora Bahêa Minha Porra!`);
});

client.on('messageCreate', (message) => {
  // Ignora mensagens de outros bots
  if (message.author.bot) return;

  const msg = message.content.toLowerCase();

  // Comando 1: Grito de guerra
  if (msg === '!bbmp') {
    message.reply('🔵🔴⚪ **BORA BAHÊA MINHA PORRA!** O maior do Nordeste!');
  }

  // Comando 2: Hino do Bahia
  if (msg === '!hino') {
    const embedHino = new EmbedBuilder()
      .setColor('#004B9B') // Azul do Bahia
      .setTitle('🎶 Hino do Esporte Clube Bahia')
      .setDescription(
        'Somos da Turma Tricolor\n' +
        'Somos a voz do campeão\n' +
        'Somos do povo o clamor\n' +
        'Ninguém nos vence em vibração!\n\n' +
        'Vamos, avante, Esquadrão!\n' +
        'Vamos, serás o vencedor!\n' +
        'Vamos, conquista mais um tento!\n' +
        'Bahia, Bahia, Bahia!'
      )
      .setFooter({ text: 'BBMP - 1931' });

    message.channel.send({ embeds: [embedHino] });
  }

  // Comando 3: Próximo jogo
  if (msg === '!jogo') {
    message.reply('🏟️ **Próximo confronto:** Confira a tabela atualizada na Arena Fonte Nova! #BBMP');
  }
});

client.login(TOKEN);